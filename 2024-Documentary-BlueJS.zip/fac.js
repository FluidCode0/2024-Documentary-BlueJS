// fac.js

const tutorials = [
    {
        title: 'Getting Started with Bluetooth',
        steps: [
            'Understand the basics of Bluetooth technology.',
            'Turn on Bluetooth on your device.',
            'Search for nearby Bluetooth devices.',
            'Select a Bluetooth device to connect to.',
            'Establish a connection with the chosen device.',
            'Access services and characteristics for data transfer.',
            'Send and receive data using Bluetooth.'
        ]
    },
    {
        title: 'Discovering Bluetooth Services',
        steps: [
            'Request available services from a connected device.',
            'Explore characteristics within each service.',
            'Understand the purpose of different services.',
            'Interact with specific characteristics for functionality.',
            'Handle data transfer through identified characteristics.'
        ]
    },
    {
        title: 'Bluetooth Notifications and Indications',
        steps: [
            'Configure notifications for specific characteristics.',
            'Handle indications for critical events.',
            'Receive real-time updates from Bluetooth devices.',
            'Implement event-driven communication.',
            'Ensure proper handling of notifications and indications.'
        ]
    },
    {
        title: 'Pair Mode: Establishing Secure Connections',
        steps: [
            'Activate pair mode on the Bluetooth device.',
            'Search for the device in pair mode from another device.',
            'Initiate pairing and exchange security credentials.',
            'Establish a secure connection between paired devices.',
            'Test the secure connection with data transfer.'
        ]
    },
    {
        title: 'Understanding Bluetooth Basics',
        steps: [
            'Learn about Bluetooth protocols and profiles.',
            'Explore Bluetooth Classic vs. Bluetooth Low Energy (BLE).',
            'Understand Bluetooth roles: central, peripheral, and observer.',
            'Explore Bluetooth devices: smartphones, wearables, speakers, etc.',
            'Get familiar with Bluetooth terminology and concepts.'
        ]
    },
    {
        title: 'Bluetooth Low Energy (BLE) Basics',
        steps: [
            'Understand the fundamentals of Bluetooth Low Energy.',
            'Explore GATT profiles in BLE applications.',
            'Implement energy-efficient communication.',
            'Handle BLE characteristics for data exchange.',
            'Optimize power consumption in BLE devices.'
        ]
    },
    {
        title: 'Creating a Bluetooth-Controlled Robot',
        steps: [
            'Design the hardware setup for a Bluetooth-controlled robot.',
            'Connect Bluetooth modules to the robot and control device.',
            'Implement communication protocols for robot control.',
            'Handle directional commands through Bluetooth.',
            'Test and refine the Bluetooth-controlled robot.'
        ]
    },
    // Add 10 more tutorials as needed
    // ...
    {
        title: 'Bluetooth Data Transfer Best Practices',
        steps: [
            'Optimize data transfer rates over Bluetooth.',
            'Handle large data payloads efficiently.',
            'Implement error checking and recovery mechanisms.',
            'Explore Bluetooth data compression techniques.',
            'Ensure reliability in Bluetooth data transmissions.'
        ]
    },
    {
        title: 'Bluetooth Range and Signal Strength',
        steps: [
            'Understand the factors influencing Bluetooth range.',
            'Explore methods to extend Bluetooth signal range.',
            'Implement signal strength monitoring in your application.',
            'Optimize Bluetooth connections for different scenarios.',
            'Test and calibrate Bluetooth signal strength.'
        ]
    },
    {
        title: 'Bluetooth Security Best Practices',
        steps: [
            'Implement secure authentication methods for Bluetooth connections.',
            'Explore encryption techniques for Bluetooth data.',
            'Handle secure pairing and key exchange.',
            'Address common Bluetooth security vulnerabilities.',
            'Stay updated on Bluetooth security standards.'
        ]
    }
    // Add more tutorials as needed
];

// You can add more tutorials and export them as needed
